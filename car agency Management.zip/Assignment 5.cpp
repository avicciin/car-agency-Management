#include <iostream>
#include <fstream>
#include "Car.h"
#include "Employee.h"

//creating by avichai kapah id 204075808 and hodaya ben harush id 214520587

template <typename T>
// Template function for sorting an array of pointers to elements of type T
void sort(T** arr, int size) {
    if (size > 0) {// Check if the array has at least one element
        T* temp;
        for (int i = 0; i < size - 1; i++) {
            // Inner loop for comparing adjacent elements
            for (int j = 0; j < size - i - 1; j++) {
                // Compare the values pointed by the pointers and swap if necessary
                if (*arr[j+1] > *arr[j]) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}

template <typename T>
// Template function for printing elements of an array of pointers to type T
void print(T** arr, int size) {
    // Check if the array has at least one element
    if (size > 0) {
        for (int i = 0; i < size; i++) {
            cout << *arr[i] << endl;// Dereference each pointer and print its value
        }
    }
}
#define EXIT 5// exit number

void Menu() {// menu func
    cout << "1. print the list of employees in the agency" << endl;
    cout << "2. Print the cars at the dealership that have not been sold" << endl;
    cout << "3. Car Sales" << endl;
    cout << "4. Adding a cars to the dealership" << endl;
    cout << "5. Exit the system" << endl;
}


int main()
{
    // Define the file name to be opened
    string fileName = "Sold.txt";
    // Create an output file stream object and open the file in append mode
    ofstream outFile(fileName, ios::app);
    // Check if the file was successfully opened
    if (!outFile) {
        cout << "Error opening file for writing: " << fileName << endl;
        return 1;
    }

    // Define the file name to be opened
    string file1 = "CarDealership.txt";
    // Create an output file stream object and open the file in append mode
    ifstream fileCar(file1,ios::app);
    // Check if the file was successfully opened
    if (!fileCar) {
        cout << "Error opening file for reading: " << file1 << endl;
        return 1;
    }
    // create a paremeter
    string name;
    int kilometer;
    int price;
    int year;
    int number;
    int CarSize = 0;
    fileCar >> CarSize; // get the size of the array car from the file
    Car** car = new Car * [CarSize];// create an array
    for (int i = 0; i < CarSize; i++) {
        fileCar >> name >> kilometer >> price >> year >> number;// eneter to the parmeter the input fron the file
        car[i] = new Car(name, kilometer, price, year, number);// create an new object in the array of car
    }

    // Define the file name to be opened
    string file2 = "Employee.txt";
    // Create an output file stream object and open the file in append mode
    ifstream fileEmployee(file2, ios::app);
    // Check if the file was successfully opened
    if (!fileEmployee) {
        cout << "Error opening file for reading:" << endl;
        return 1;
    }
    int sizeEmployee = 0;
    fileEmployee >> sizeEmployee;// enter the size of employee array from the file
    Employee** employee = new Employee * [sizeEmployee];// create an array

    string nameEmploye;
    int id;
    int numberOfSelas;

    for (int i = 0; i < sizeEmployee; i++) {
        fileEmployee >> nameEmploye >> id >> numberOfSelas;// eneter to the parmeter the input fron the file
        employee[i] = new Employee(nameEmploye, id, numberOfSelas);// create an new object in the array of employee
    }
    //----------------------------------------------------------------------------------------


    int choice = 0;
    while (choice != EXIT) {// a loop until input exit
        Menu();// call the func menu
        cout << "enter you choice: " << endl;
        cin >> choice;// input choice
        switch (choice) {

        case 1: {
            sort(employee, sizeEmployee);// call the func sort
            print(employee, sizeEmployee);// call the func print
            break;
        }
        case 2: {
            print(car, CarSize);// call the func print
            break;
        }

        case 3: {
            // Initialize pointer for selected employee to null
            Employee* SelectEmployee = nullptr;
            int idEmployee;// Variable to store employee ID input by user
            print(employee, sizeEmployee);// Print list of employees
            int count = 0;// Counter for verifying if employee ID exists
            do {// Loop until a valid employee ID is entered
                cout << "enter the id employee of your choice: " << endl;
                cin >> idEmployee;// Input employee ID from user
                for (int i = 0; i < sizeEmployee; i++) {// Search for the employee ID in the array of employees
                    if (idEmployee == employee[i]->getId()) {
                        count++;// Increment count if ID is found
                        SelectEmployee = employee[i];// Set selected employee
                    }
                }
                if (count == 0) { // If no matching ID is found, print error message
                    cout << "Error id input try again" << endl;
                }
            } while (count == 0);// Repeat loop if no ID was found
            cout << "selected employee successfully" << endl;

            // Similar process for selecting a car
            print(car, CarSize);
            Car* SelectCar = nullptr;
            int numberOfCar;
            int count2 = 0;
            do {
                cout << "enter the car you choice " << endl;
                cin >> numberOfCar;
                for (int i = 0; i < CarSize; i++) {
                    if (numberOfCar == car[i]->get_number()) {
                        count2++;
                        SelectCar = car[i];
                    }
                }
                if (count2 == 0) {// If no matching number is found, print error message
                    cout << "Error car input try again" << endl;
                }
            } while (count2 == 0);// Repeat loop if no number was found
            cout << "selected car successfully" << endl;
            // Process the sale of the selected car by the selected employee
            if (SelectEmployee->soldCar(outFile, *SelectCar)) {
                Car** temp = new Car * [CarSize - 1];// Create new array with one less Car pointer
                int j = 0;// Index for new array
                for (int i = 0; i < CarSize; i++) {// Copy all pointers except the sold car into the new array
                    if (car[i] != SelectCar) {
                        temp[j++] = car[i];
                    }
                }

                delete[] car;// Delete old array of pointers
                car = temp;// Point to new array of pointers
                CarSize--; // Decrement size of array
                cout << "the car sold succefully " << endl;
                break;
            }

            cout << "Error of sold car" << endl;

            break;
        }



        case 4: {
            string name;
            int kilometer;
            int price;
            int year;
            int number;
            cout << "Enter the name of the car" << endl;
            cin >> name;
            cout << "Enter kilometer of the car " << endl;
            cin >> kilometer;
            cout << "Enter price of the car" << endl;
            cin >> price;
            cout << "Enter year of Prodction" << endl;
            cin >> year;
            cout << "Enter number of car" << endl;
            cin >> number;

            // Create a new Car object with the inputted details
            Car* newCar = new Car(name, kilometer, price, year, number);
            // Create a new array of Car pointers with an additional slot for the new car
            Car** temp = new Car * [CarSize + 1];
            // Copy existing car pointers into the new array
            for (int i = 0; i < CarSize; i++) {
                temp[i] = car[i];
            }
            temp[CarSize] = newCar;// Add the new car to the end of the array

            delete[] car;// Delete the old array and point to the new array
            car = temp;
            CarSize++;// Increment the size of the array to reflect the addition of the new car
            cout << "the car add succefully " << endl;
            break;
        }




        case 5: {
            // Open the car file for writing and truncate it if it already exists
            ofstream outFileCar(file1, ios::trunc);
            if (!outFileCar) {
                cerr << "Error opening file for writing: " << endl;
                return 1;
            }
            outFileCar << CarSize << endl;// Write the number of cars to the file
            for (int i = 0; i < CarSize; i++) {
                // Write each car's details to the file
                outFileCar << car[i]->get_name() << " " << car[i]->get_kilometer() << " " << car[i]->get_price();
                outFileCar << " " << car[i]->get_yearsOfProdction() << " " << car[i]->get_number() << endl;
            }

            // Open the employee file for writing and truncate it if it already exists
            ofstream outFileEmployee(file2, ios::trunc);
            if (!outFileEmployee) {
                cerr << "Error opening file for writing: " << endl;
                return 1;
            }
            // Write the number of employees to the file
            outFileEmployee << sizeEmployee << endl;
            for (int i = 0; i < sizeEmployee; i++) {// Write each employee's details to the file
                outFileEmployee << employee[i]->get_name() << " " << employee[i]->getId() << " " << employee[i]->get_number() << endl;
            }

            // Close both files
            outFileEmployee.close();
            outFileCar.close();

            // Deallocate memory for employees and cars arrays
            delete[] employee;
            delete[] car;
            cout << "bye" << endl;

            break;

        }

        default: {// input error
            cout << "Error input please try again" << endl;
            break;
        }


               return 0;
        }// end switch
    }//end loop
}//end main
