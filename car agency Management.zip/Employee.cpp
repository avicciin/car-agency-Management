#include "Employee.h"
//creating by avichai kapah id 204075808 and hodaya ben harush id 214520587
Employee::Employee(string nameOfEmployee, int id)//constructor prameter
{
	this->nameOfEmployee = nameOfEmployee;
	this->id = id;
	this->namberOfSales = 0;
}

Employee::Employee(string nameOfEmployee, int id, int namberOfSales)//constructor prameter
{
	this->nameOfEmployee = nameOfEmployee;
	this->id = id;
	this->namberOfSales = namberOfSales;
}

bool Employee::soldCar(ofstream& outFile, Car c1)// get a parmeter of a file and object of car
{
	if (c1.carSales(outFile)) {//Add the sold car to the list of the sale
		namberOfSales++;//we increased the array
		return true;
	}
	return false;
}

int Employee::salary()const//emoloyee salary calculation 
{
	int salary=6000;// starting salary
	if (namberOfSales > 0) {// if he had sales
		salary = 6000 + 100 * namberOfSales;// recalculatin of the salary according to thr amount of sales
		return salary;
	}
		return salary;
}


ostream& operator<<(ostream& os, const Employee& employee)// output operator
{
	os << "name of employee: " << employee.nameOfEmployee << endl;
	os << "id of employee: " << employee.id << endl;
	os << "number of sales" << employee.namberOfSales << endl;
	os << "the salary: " << employee.salary() << endl;
	return os;
}

bool Employee::operator>(const Employee& other)// operator comparison size
{
	if (this->namberOfSales > other.namberOfSales) {
		return true;
	}
	return false;
}
