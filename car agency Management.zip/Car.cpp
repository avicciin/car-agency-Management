#include "Car.h"
#include <iostream>
//creating by avichai kapah id 204075808 and hodaya ben harush id 214520587

Car::Car(string nameOfManu, int kilometer, int price, int yearsOfProdction, int number)//constructor parameter
{
	set_number(number);
	set_yearsOfProdction(yearsOfProdction);
	this->nameOfManu = nameOfManu;
	this->kilometer = kilometer;
	this->price = price;
}




ostream& operator <<(ostream& os, const Car& car)// out put operator
{
	os << "name Of Manufacturer: " << car.nameOfManu << endl;
	os << "kilometer: " << car.kilometer << endl;
	os << "the price: " << car.price << endl;
	os << "year of Prodction: " << car.yearsOfProdction << endl;
	os << "namber of car: " << car.number << endl;
	

	return os;
}

bool Car::carSales(ofstream& outFile)
{
	if (!outFile) {// we checking if the file open
		cout << "Error opening file for writing" << endl;
		return false;
	}
	outFile << nameOfManu << " " << kilometer << " " << price << " ";// we enter the details of the car we sale to the file
	outFile << yearsOfProdction << " " << number << endl;
	outFile.close();// close the file
	if (outFile.fail()) {// we checking if the file close
		cerr<< "Error closing the file: " << endl;
		return false;
	}
	cout << "File written successfully " << endl;
	return true;
}


void Car::set_yearsOfProdction(int yearsOfProdction)// set to the year of prodction
{
	if (yearsOfProdction < 2017 || yearsOfProdction>2023) {// if the year betwen 2017 to 2023
		cout << "error year" << endl;
		yearsOfProdction = -1;
		return;
	}
	this->yearsOfProdction = yearsOfProdction;
}



int Car::get_yearsOfProdction() const// get to the year of prodction
{
	return yearsOfProdction;
}

void Car::lowPrice(int numOflow)// this func will low the price by the parametr percentage 
{
	if (numOflow > 100) {
		cout << "Error input percentages should be up to 100!" << endl;
		return;
	}
	else {
		int lowPrice = price * (numOflow / 100);//the count of the new price
		if (lowPrice > 5000) {//if the low of the price is more then 5000
			cout << "The price reduction is too high" << endl;
			return;
		}
		else {
			this->price = price - lowPrice;
		}
	}
}

void Car::set_number(int number)
{
	if (number < 100000 || number>999999) {//number of car is 6 digit
		cout << "error number of car: " << endl;
		number = -1;
		return;
	}
	this->number = number;
}

int Car::get_number() const
{
	return number;
}

