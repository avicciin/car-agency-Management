#pragma once
#include <iostream>
#include <fstream>
#include <String>
#include "Car.h"
using namespace std;
//creating by avichai kapah id 204075808 and hodaya ben harush id 214520587
class Employee

{
private:
	string nameOfEmployee;
	int id;
	int namberOfSales;

public:
	Employee(string nameOfEmployee, int id);//constructor parameter
	Employee(string nameOfEmployee, int id, int namberOfSales);//constructor parameter
	bool soldCar(ofstream& outFile, Car c1);// a bool func 
	int salary()const;// func of salary calculation
	friend ostream& operator<<(ostream& os, const Employee& employee);// output operator
	bool operator>(const Employee& other);
	int getId() {
		return id;

	}
	string get_name() {
		return  nameOfEmployee;
	}

	int get_number() const
	{
		return namberOfSales;
	}
};

