#pragma once
#include <iostream>
#include <fstream>
#include <String>
using namespace std;
//creating by avichai kapah id 204075808 and hodaya ben harush id 214520587
class Car
{
private:
	int number;
	int yearsOfProdction;
	string nameOfManu;
	int kilometer;
	int price;
public:
	Car(string nameOfManu, int kilometer, int price, int yearsOfProdction, int number);//constructor parameter
	friend ostream& operator<<(ostream& os, const Car& car);// operator func
	bool carSales(ofstream& outFile);// func of sale car
	void set_yearsOfProdction(int yearsOfProdction);
	int get_yearsOfProdction()const;
	void lowPrice(int numOflow);
	void set_number(int number);
	int get_number()const;
	string get_name() {
		return nameOfManu;
	}
	int get_kilometer() {
		return kilometer;
	}
	int get_price() {
		return price;
	}
};

